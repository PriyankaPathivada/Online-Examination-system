package com.bhagyashri.Online_Examination_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineExaminationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
